package LianLianKan.gujiacong;
/**
 * ���ô��ڴ�С
 */
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class SimpleFrame extends JFrame{
public SimpleFrame() {
	super();
}
public void sizeWindowOnScreen(SimpleFrame mainFrame, double widthRate, double heightRate)
{
   Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
  
   mainFrame.setSize(new Dimension((int)(screenSize.width * widthRate),(int)(screenSize.height *heightRate)));
}
}
