package LianLianKan.gujiacong;
/**
 * ���ɴ��ڡ��ж���������ʱ�������¿�ʼ�����С��жϳɰ�
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FilenameFilter;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;





public class LianLianKan implements ActionListener {
	SimpleFrame mainFrame;
	 Container thisContainer;
	 JPanel  centerPanel,southPanel, northPanel; 
	 JButton diamondsButton[][] = new JButton[6][5];  	  
	 JButton exitButton, resetButton, newlyButton,stopButton;
	 ImageIcon icon = new ImageIcon("picture\\5.png");
	 ImageIcon icon1 = new ImageIcon("picture\\6.png");
	 ImageIcon icon2 = new ImageIcon("picture\\7.png");
	 JLabel fractionLable = new JLabel("0");
	 JLabel jl1,jl2,jl3;
	 JButton firstButton, secondButton;
	 static long time = 120;
	 static int grid[][] = new int[8][7];
	 static boolean pressInformation = false; 
	 int x0 = 0, y0 = 0, x = 0, y = 0, fristMsg =0, secondMsg = 0, validateLV;
	 int i, j, k, n;
	 static Icon[] icons = new ImageIcon[30];
	 static final String imgDir = "picture";
		static {
			try
			{
				File dir = new File(imgDir);
				File[] imgFiles = dir.listFiles(new FilenameFilter() {
					public boolean accept(File dir, String name) {
						return name.toLowerCase().endsWith(".png");
					}
				});
				for (int i = 0; i < 30; i++) {
					icons[i] = new ImageIcon(imgFiles[i].getAbsolutePath());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	 
	 public void init(int f) {		 
	  mainFrame = new SimpleFrame();
	  mainFrame.setTitle("������");
     thisContainer = mainFrame.getContentPane();

	  thisContainer.setLayout(new BorderLayout());
	  centerPanel = new JPanel() {  
      	  
		        public void paintComponent(Graphics g) {  
	                ImageIcon icon = new ImageIcon("picture\\����.jpg"); 
	                Image img = icon.getImage();  
	                g.drawImage(img, 0, 0, mainFrame.getWidth(), mainFrame.getHeight(),
	                		icon.getImageObserver());   
	  
	            }  
	  
	        };
	        northPanel = new JPanel(){  
	         	  
	            public void paintComponent(Graphics g) {  
	                ImageIcon icon = new ImageIcon("picture\\����.jpg");  
	                Image img = icon.getImage();  
	                g.drawImage(img, 0, 0, mainFrame.getWidth(),  
	                		mainFrame.getHeight()*1/15, icon.getImageObserver());   
	  
	            }  
	  
	        };
	        southPanel = new JPanel() {  
	         	  
	        	public void paintComponent(Graphics g) {  
	                ImageIcon icon = new ImageIcon("picture\\����.jpg");  
	                Image img = icon.getImage();  
	                g.drawImage(img, 0, 0, mainFrame.getWidth(),  
	                		mainFrame.getHeight(), icon.getImageObserver());   
	  
	            }  
	  
	        };
	        
	  jl1=new JLabel();
	  jl2=new JLabel();
	  jl3=new JLabel();
      southPanel.add(jl1);
      southPanel.add(jl2);
      
      
      
	  thisContainer.add(northPanel,"North");       
	  thisContainer.add(centerPanel,"Center");
	  thisContainer.add(southPanel,"South");
 	  
	  centerPanel.setLayout(new GridLayout(6, 5));	  

	  for (int cols = 0; cols < 6; cols++) {
	   for (int rows = 0; rows < 5; rows++) {
	    diamondsButton[cols][rows] = new JButton(String
	      .valueOf(grid[cols + 1][rows + 1]));
	   diamondsButton[cols][rows] = new JButton(
				icons[grid[cols + 1][rows + 1]]);
	   diamondsButton[cols][rows].setContentAreaFilled(false);
	   diamondsButton[cols][rows].addActionListener(this);
	   centerPanel.add(diamondsButton[cols][rows]);
	   }
	  }
	  	  
	  
	  exitButton = new JButton("�˳�");
	  exitButton.setBounds(0, 0, 25, 20);
	  exitButton.setOpaque(false);
	  exitButton.setContentAreaFilled(false);
	  exitButton.setFocusPainted(false);
	  Image temp = icon.getImage().getScaledInstance(exitButton.getWidth(), exitButton.getHeight(), icon.getImage().SCALE_DEFAULT);
	  icon = new ImageIcon(temp);
	  exitButton.setIcon(icon);
	  exitButton.addActionListener(this);
	  
	  resetButton = new JButton("����");
	  resetButton.setBounds(0, 0, 25, 20);
	  resetButton.setOpaque(false);
	  resetButton.setContentAreaFilled(false);
	  resetButton.setFocusPainted(false);
	  Image temp1 = icon1.getImage().getScaledInstance(resetButton.getWidth(), resetButton.getHeight(), icon1.getImage().SCALE_DEFAULT);
	  icon1 = new ImageIcon(temp1);
	  resetButton.setIcon(icon1);
	  resetButton.addActionListener(this);
	  
	  newlyButton = new JButton("���¿�ʼ");
	  newlyButton.setBounds(0, 0, 25, 20);
	  newlyButton.setOpaque(false);
	  newlyButton.setContentAreaFilled(false);
	  newlyButton.setFocusPainted(false);
	  Image temp2 = icon2.getImage().getScaledInstance(newlyButton.getWidth(), newlyButton.getHeight(), icon2.getImage().SCALE_DEFAULT);
	  icon2 = new ImageIcon(temp2);
	  newlyButton.setIcon(icon2);
	  newlyButton.addActionListener(this);
	  
	  
	  southPanel.add(exitButton);
	  southPanel.add(resetButton);
	  southPanel.add(newlyButton);
      southPanel.add(jl3);
	  
	 fractionLable.setText(String.valueOf(Integer.parseInt(fractionLable
	    .getText())));
	 fractionLable.setFont(new java.awt.Font("Dialog",1,20));
	 fractionLable.setForeground(Color.RED);
	  northPanel.add(fractionLable);

	  mainFrame.sizeWindowOnScreen(mainFrame,0.38,0.7);
	  Toolkit tool=mainFrame.getToolkit(); 
	  Image myimage=tool.getImage("picture/6.png");
	  mainFrame.setIconImage(myimage);
	  /*mainFrame.setIconImage(new ImageIcon("����.jpg").getImage());*/
	  mainFrame.setVisible(true);	  
	  mainFrame.setDefaultCloseOperation(mainFrame.EXIT_ON_CLOSE);		  
  
	  if(f==0) {
          getTime();
	  }else if(f==1){ 
		  time=120;
	  }
}
	 public void fen() {
		 int save[] = new int[30];
		  int n = 0,m =30, cols, rows;
		  int grid[][] = new int[8][7];
		  for (int i = 0; i <= 6; i++) {
		   for (int j = 0; j <= 5; j++) {
		    if (this.grid[i][j] != 0) {
		     save[n] = this.grid[i][j];
		     n++;
		    }
		   }
		  }
		  
	      jl3.setText("������"+(m-n));    
	 }
	 
	 
	 public void getTime() {
		 new Thread(()->{
			 /*public volatile boolean exit = false;*/
			time = 120;
	        long hour = 0;
	        long minute = 0;
	        long seconds = 0;
	        	while (time >= 0) {
	            minute = (time - hour * 3600) / 60;
	            seconds = time - hour * 3600 - minute * 60;
	            jl1.setText(minute + "��");
	            jl2.setText(seconds + "��");
	            try {
	                Thread.sleep(1000);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	            time--;
	        }	        
	        	
	        JOptionPane.showMessageDialog(mainFrame, "��սʧ�ܣ����ȷ�����¿�ʼ");

	        int grid[][] = new int[8][7];
	 	   LianLianKan.grid = grid;
	 	   randomBuild();
	 	   fractionLable.setText("0");
	 	   mainFrame.setVisible(false);
	 	   pressInformation = false;
	 	   init(0);

		 }).start();



	 }	 
	 
	 public void randomBuild() {
	  int randoms, cols, rows;
	  for (int twins = 1; twins <= 15; twins++){
	   randoms = (int) (Math.random() * 25 +1);
	   for (int alike = 1; alike <= 2; alike++){
	    cols = (int) (Math.random() * 6 + 1);
	    rows = (int) (Math.random() * 5 + 1);
	    while (grid[cols][rows] != 0) {
	     cols = (int) (Math.random() * 6 + 1);
	     rows = (int) (Math.random() * 5 + 1);
	    }
	    this.grid[cols][rows] = randoms;
	   }
	  }
	 }
	 
	 public void fraction() {
	 fractionLable.setText(String.valueOf(Integer.parseInt(fractionLable
	    .getText()) + 100));
	 }
	 
    public void reload() {
	  int save[] = new int[30];
	  int n = 0, cols, rows;
	  int grid[][] = new int[8][7];
	  for (int i = 0; i <= 6; i++) {
	   for (int j = 0; j <= 5; j++) {
	    if (this.grid[i][j] != 0) {
	     save[n] = this.grid[i][j];
	     n++;
	    }
	    }
	  }
	  n = n - 1;
	  this.grid = grid;
	  while (n >= 0) {
	   cols = (int) (Math.random() * 6 + 1);
	   rows = (int) (Math.random() * 5 + 1);
	   while (grid[cols][rows] != 0) {
	    cols = (int) (Math.random() * 6 + 1);
	    rows = (int) (Math.random() * 5 + 1);
	   }
	   this.grid[cols][rows] = save[n];
	   n--;
	  }
	  
	  mainFrame.setVisible(false);
	  pressInformation = false;
	  init(2);
	  for (int i = 0; i < 6; i++) {
	        for (int j = 0; j < 5; j++) {
	          if (grid[i + 1][j + 1] == 0)
	              diamondsButton[i][j].setVisible(false);
	   }
	  }

	 }
	 
	 public void judgeEven(int placeX, int placeY, JButton bz) {
	  if (pressInformation == false) {
	   x = placeX;
	   y = placeY;
	   secondMsg = grid[x][y];
	   secondButton = bz;
	   pressInformation = true;
	  } else {
	   x0 = x;
	   y0 = y;
	   fristMsg = secondMsg;
	   firstButton = secondButton;
	   x = placeX;
	   y = placeY;
	   secondMsg = grid[x][y];
	   secondButton = bz;
	   if (fristMsg == secondMsg &&secondButton != firstButton) {
	    xiao();
	    fen();
	   }
	  }
	 isFinished();
	  } 
	
	 
	 public void xiao() {
	  if ((x0 == x && (y0 == y + 1 || y0 ==y - 1))
	    || ((x0 == x + 1 || x0 == x - 1) &&(y0 == y))) { // �ж��Ƿ�����
	   remove();
	  } else {
	   for (j = 0; j < 7; j++) {
	    if (grid[x0][j] == 0) {

	     
	     if (y > j) {//�ڶ�����ť�ڿհ�ť�ұ�
	      for (i = y - 1; i >= j; i--) {
	       if (grid[x][i] != 0) {
	        k = 0;
	        break;
	       } else {
	        k = 1;
	       }
	      }
	      if (k == 1) {
	       linePassOne();
	      }
	     }
	     
	     if (y < j) { 
	      for (i = y + 1; i <= j; i++) {
	       if (grid[x][i] != 0) {
	        k = 0;
	        break;
	       } else {
	        k = 1;
	       }
	      }
	      if (k == 1) {
	       linePassOne();
	      }
	     }
	     
	     if (y == j) {//�ڶ�����ť�Ϳհ�ťͬ��
	      linePassOne();
	     }
	    }
	    

	    if (k == 2) {
	     if (x0 == x) {
	      remove();
	     }
	     
	     if (x0 < x) {//��һ��ť�ڵڶ���ť�±�
	      for (n = x0; n <= x - 1; n++) {
	       if (grid[n][j] != 0) {
	        k= 0;
	        break;
	       }
	       if (grid[n][j] == 0 && n == x -1) {
	        remove();
	       }
	      }
	     }
	     
	     if (x0 > x) {
	      for (n = x0; n >= x + 1; n--) {
	       if (grid[n][j] != 0) {
	        k = 0;
	        break;
	       }
	       if (grid[n][j] == 0 && n == x +1) {
	        remove();
	       }
	      }
	     }
	    }
	    
	   }
	   

	   for (i = 0; i < 8; i++) { 
	    if (grid[i][y0] == 0) {
	     if (x > i) {//�ڶ�����ť������հ�ť������
	      for (j = x - 1; j >= i; j--) {
	       if (grid[j][y] != 0) {
	        k = 0;
	        break;
	       } else {
	        k = 1;
	       }
	      }
	      if (k == 1) {
	       rowPassOne();
	      }
	     }
	     
	     if (x < i) {
	      for (j = x + 1; j <= i; j++) {
	       if (grid[j][y] != 0) {
	        k = 0;
	        break;
	       } else {
	        k = 1;
	       }
	      }
	      if (k == 1) {
	       rowPassOne();
	      }
	     }
	     
	     if (x == i) {//�ڶ�����ť������հ�ťͬ��
	      rowPassOne();
	     }
	    }
	    
	    if (k == 2) {
	     if (y0 == y) {//�ڶ�����ť���һ����ťͬ��
	      remove();
	     }
	     if (y0 < y) {//�ڶ�����ť�ڵ�һ����ť�ұ�
	      for (n = y0; n <= y - 1; n++) {
	       if (grid[i][n] != 0) {
	        k = 0;
	        break;
	       }
	       if (grid[i][n] == 0 && n == y -1) {
	        remove();
	       }
	      }
	     }
	     if (y0 > y) {
	      for (n = y0; n >= y + 1; n--) {
	       if (grid[i][n] != 0) {
	        k = 0;
	        break;
	       }
	       if (grid[i][n] == 0 && n == y +1) {
	        remove();
	       }
	      }
	     }
	    }
	   }
	  }
	 }
	 
	 public void linePassOne() {
	  if (y0 > j) { // ��һ��ťͬ�пհ�ť�����
	   for (i = y0 - 1; i >= j; i--) {
	    if (grid[x0][i] != 0) {
	     k = 0;
	     break;
	    } else {
	     k = 2;
	    }	   
	    }
	  }
	  
	  if (y0 < j) { 
	   for (i = y0 + 1; i <= j; i++) {
	    if (grid[x0][i] != 0) {
	     k = 0;
	     break;
	    } else {
	     k = 2;
	    }
	   }
	  }
	 }
	 
	 public void rowPassOne() {
	  if (x0 > i) {//��һ����ť������ͬ�е��Ǹ��ո�ť����
	   for (j = x0 - 1; j >= i; j--) {
	    if (grid[j][y0] != 0) {
	     k = 0;
	     break;
	    } else {
	     k = 2;
	    }
	   }
	  }
	  
	  if (x0 < i) {
	   for (j = x0 + 1; j <= i; j++) {
	    if (grid[j][y0] != 0) {
	     k = 0;
	     break;
	    } else {
	     k = 2;
	    }
	   }
	  }
	 }
	 
	 public void remove() {
	  firstButton.setVisible(false);
	  secondButton.setVisible(false);
	  fraction();
	  pressInformation = false;
	  k = 0;
	  grid[x0][y0] = 0;
	  grid[x][y] = 0;
	 }
	 public void isFinished()
	 {
		 int save[] = new int[30];
		  int n = 0, cols, rows;
		  int grid[][] = new int[8][7];
		  for (int i = 0; i <= 6; i++) {
		   for (int j = 0; j <= 5; j++) {
		    if (this.grid[i][j] != 0) {
		     save[n] = this.grid[i][j];
		     n++;
		    }
		    }
		   }
		  if(n==0)
		  {
			  JOptionPane.showMessageDialog(mainFrame, "��ս�ɹ������ȷ�����¿�ʼ"); 		  
		      this.grid = grid;
		      randomBuild();
		      fractionLable.setText("0");
		      mainFrame.setVisible(false);
		      pressInformation = false;
		      
		      init(1);
		  }
	 }
	 public void actionPerformed(ActionEvent e) {
	  if (e.getSource() == newlyButton) {
	   int grid[][] = new int[8][7];
	   this.grid = grid;
	   randomBuild();
	   fractionLable.setText("0");
	   mainFrame.setVisible(false);
	   pressInformation = false;
	  init(1);	  
	   
	  }

	  if (e.getSource() == exitButton)
	   System.exit(0);
	  if (e.getSource() == resetButton)
	   reload();	  

	  for (int cols = 0; cols < 6; cols++) {
	   for (int rows = 0; rows < 5; rows++) {
	    if (e.getSource() ==diamondsButton[cols][rows])
	    	judgeEven(cols + 1, rows + 1,diamondsButton[cols][rows]);
	   }
	  }

	 }
	 
	 public static void main(String[] args) {
	 LianLianKan llk = new LianLianKan();
	  llk.randomBuild();
	  llk.init(0);
	 }
	}

